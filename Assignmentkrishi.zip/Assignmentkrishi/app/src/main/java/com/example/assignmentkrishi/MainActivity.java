package com.example.assignmentkrishi;

import android.os.Bundle;;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
 private static final String TAG ="MainActivity";
    YouTubePlayerView mYouTubePlayerView;
    Button play;
    YouTubePlayer.OnInitializedListener onInitializedListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play=findViewById(R.id.play);
//        mYouTubePlayerView=findViewById(R.id.Youtubeplayer);
        onInitializedListener=new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                Log.d(TAG,"Onclick:Done  Initializing,");
                List<String>videoList=new ArrayList<>();
                videoList.add("IEF6mw7eK4s");
                videoList.add("8CEJoCr_9UI");
                videoList.add("344u6uK9qeQ");
                videoList.add("3-nM3yNi3wg");
                videoList.add("RlcY37n5j9M");
                videoList.add("nB7nGcW9TyE");
            }
            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
         Log.d(TAG,"Onclick:Failed to initialize,");
            }
        };

        play.setOnClickListener(view -> {
            Log.d(TAG,"OnClick: Initializing Youtube player") ;
           mYouTubePlayerView.initialize(YoutubeConfig.getApiKey(),onInitializedListener);

        });

    }
}