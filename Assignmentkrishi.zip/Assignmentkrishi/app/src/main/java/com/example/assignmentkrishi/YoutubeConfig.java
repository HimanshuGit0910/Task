package com.example.assignmentkrishi;

public class YoutubeConfig {
    public YoutubeConfig() {
    }

    private static final String API_KEY="AIzaSyD0ZQVheE9Off0CCd66TRI746LLpWXJVv0";

    public static String getApiKey() {
        return API_KEY;
    }
}
